# Homework for Introduction to Artificial Intelligence, UC Berkeley CS188.  
The famous course is very helpful and important for deeper learning in AI.
CS188 2019 summer version  
Completed in 2019/06.  

## PJ1_search  
![PJ1_search](./Screenshot/PJ1_Search.png)

## PJ2_multiagent  
![PJ2_multiagent](./Screenshot/PJ2_MultiAgentSearch.png)

## PJ3_reinforcement  
![PJ3_reinforcement](./Screenshot/PJ3_ReinforcementLearning.png)
![PJ3_results](./Screenshot/PJ3_results.png)

## PJ4_Ghostbusters 
![PJ4_Ghostbusters](./Screenshot/PJ4_Ghostbusters.png)

![PJ4_results](./Screenshot/PJ4_results.jpeg)  
 

## PJ5_machinelearning  
In this Project, Q4 requires me to implement a RNN myself, using ReLu for activation, including bias in the model.  
![PJ5_machinelearning ](./Screenshot/PJ5_MachineLearning.png)
